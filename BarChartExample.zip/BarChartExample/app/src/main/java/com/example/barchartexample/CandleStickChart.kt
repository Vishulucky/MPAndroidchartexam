@file:Suppress("DEPRECATION")

package com.example.barchartexample

import android.R.attr.entries
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.CandleData
import com.github.mikephil.charting.data.CandleDataSet
import com.github.mikephil.charting.data.CandleEntry
import kotlinx.android.synthetic.main.activity_candle_stick_chart.*


class CandleStickChart : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_candle_stick_chart)

        setCandleStickChart()


    }


    fun setCandleStickChart()
    {

        // x values

        val xvalue = ArrayList<String>()
        xvalue.add("10:00 AM")
        xvalue.add("11:00 AM")
        xvalue.add("12:00 AM")
        xvalue.add("3:00 PM")
        xvalue.add("5:00 PM")
        xvalue.add("8:00 PM")
        xvalue.add("10:00 PM")
        xvalue.add("12:00 PM")
        // Y axis

        val candlestickentry = ArrayList<CandleEntry>()


        candlestickentry.add(CandleEntry(0,225.0f,219.84f,224.94f,226.41f))
        candlestickentry.add(CandleEntry(1,228.0f,222.14f,223.00f,212.41f))
        candlestickentry.add(CandleEntry(2,226.84f,217.84f,222.9f,229.41f))
        candlestickentry.add(CandleEntry(3,222.0f,216.12f,214.14f,216.41f))
        candlestickentry.add(CandleEntry(4,226.56f,212.84f,224.33f,229.41f))
        candlestickentry.add(CandleEntry(5,221.12f,269.84f,228.14f,216.41f))
        candlestickentry.add(CandleEntry(6,220.96f,237.84f,224.94f,246.41f))

        val candledataset = CandleDataSet(candlestickentry,"first")
        candledataset.color = Color.rgb(80,80,80)
        candledataset.shadowColor= resources.getColor(R.color.green)
        candledataset.shadowWidth = 1f
        candledataset.decreasingColor= resources.getColor(R.color.red)
        candledataset.decreasingPaintStyle = Paint.Style.FILL

        candledataset.increasingColor= resources.getColor(R.color.green)
        candledataset.increasingPaintStyle = Paint.Style.FILL

        val candledata = CandleData(xvalue,candledataset)
        candlechart.data = candledata
        candlechart.setBackgroundColor(resources.getColor(R.color.white))
        candlechart.animateXY(3000,3000)


        val xval = candlechart.xAxis
        xval.position= XAxis.XAxisPosition.BOTTOM
        xval.setDrawGridLines(false)











    }


}
