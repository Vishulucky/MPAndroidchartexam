@file:Suppress("DEPRECATION")

package com.example.barchartexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        setBarChartValues()
    }


    fun setBarChartValues()
    {
        // x axis values


        val xvalues = ArrayList<String>()
        xvalues.add("Monday")
        xvalues.add("Tuesday")
        xvalues.add("Wednesday")
        xvalues.add("Thursday")
        xvalues.add("Friday")
        xvalues.add("Saturday")
        xvalues.add("Sunday")



        // bar entries
        val barentries = ArrayList<BarEntry>()

        barentries.add(BarEntry(4f , 0))
        barentries.add(BarEntry(3.5f , 1))
        barentries.add(BarEntry(8.2f , 2))
        barentries.add(BarEntry(5.6f , 3))
        barentries.add(BarEntry(2f , 4))
        barentries.add(BarEntry(6f , 5))
        barentries.add(BarEntry(9f , 6))




        // bardata set
        val bardataset = BarDataSet(barentries,"First")
        bardataset.color = resources.getColor(R.color.darkblue)
        // make a bar data

        val data = BarData(xvalues,bardataset)

        barChart.data = data

        barChart.setBackgroundColor(resources.getColor(R.color.colorAccent))
        barChart.animateXY(3000,3000)







    }


}
