@file:Suppress("DEPRECATION")

package com.example.barchartexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import kotlinx.android.synthetic.main.activity_line_chart.*

class LineChartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_line_chart)

        setLineChartData()

    }


    fun setLineChartData()
    {

        val xvalue = ArrayList<String>()
        xvalue.add("11.00 AM")
        xvalue.add("12.00 AM")
        xvalue.add("1.00 AM")
        xvalue.add("3.00 PM")
        xvalue.add("7.00 PM")



        val lineentry = ArrayList<Entry>();
        lineentry.add(Entry(20f,0))
        lineentry.add(Entry(50f,1))
        lineentry.add(Entry(60f,2))
        lineentry.add(Entry(30f,3))
        lineentry.add(Entry(10f,4))



        val linedataset = LineDataSet(lineentry,"First")
        linedataset.color= resources.getColor(R.color.green)


        val data = LineData(xvalue,linedataset)
        lineChart.data = data
        lineChart.setBackgroundColor(resources.getColor(R.color.white))
        lineChart.animateXY(3000,3000)



    }




}
