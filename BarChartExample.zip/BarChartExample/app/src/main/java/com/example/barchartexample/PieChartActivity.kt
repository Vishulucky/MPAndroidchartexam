package com.example.barchartexample

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import kotlinx.android.synthetic.main.activity_pie_chart.*

class PieChartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pie_chart)


         setPieChart()


    }



     fun setPieChart()
     {

         // xvalues
         val xvalues = ArrayList<String >()
         xvalues.add("Coal")
         xvalues.add("Petrolium")
         xvalues.add("Natural Gas")
         xvalues.add("Renewable Energy")
         xvalues.add("Nuclear")


         // yvalues



         val piechartentry = ArrayList<Entry>()


         piechartentry.add( Entry(23.5f, 0 ))
         piechartentry.add( Entry(45.5f, 1 ))
         piechartentry.add( Entry(68.5f, 2 ))






         // fill the chart
         val piedataset = PieDataSet(piechartentry," Consumption")

         piedataset.color= resources.getColor(R.color.green)


         piedataset.sliceSpace=3f
         val data = PieData( xvalues,piedataset)
         piechart.data = data


         piechart.holeRadius = 5f
         piechart.setBackgroundColor(resources.getColor(R.color.gray))








     }



}
