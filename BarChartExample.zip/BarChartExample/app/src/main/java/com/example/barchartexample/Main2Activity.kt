package com.example.barchartexample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.*
import kotlinx.android.synthetic.main.activity_main2.*


class Main2Activity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        //setCombinedChart()
    }




    fun setCombinedChart()
    {
        val xvalue = ArrayList<String>()
        xvalue.add("11.00 AM")
        xvalue.add("12.00 AM")
        xvalue.add("1.00 AM")
        xvalue.add("3.00 PM")
        xvalue.add("7.00 PM")



        val xvalue1 = ArrayList<String>()
        xvalue1.add("12.00 AM")
        xvalue1.add("1.00 AM")
        xvalue1.add("3.00 AM")
        xvalue1.add("5.00 PM")
        xvalue1.add("8.00 PM")




        val lineentry = ArrayList<Entry>();
        lineentry.add(Entry(60f,0))
        lineentry.add(Entry(40f,1))
        lineentry.add(Entry(20f,2))
        lineentry.add(Entry(10f,3))
        lineentry.add(Entry(5f,4))



        val linedataset = LineDataSet(lineentry,"First")
        linedataset.color= resources.getColor(R.color.green)
        val data = LineData(xvalue,linedataset)

        data.addDataSet(linedataset)


        val lineentry1 = ArrayList<Entry>();
        lineentry1.add(Entry(10f,0))
        lineentry1.add(Entry(40f,1))
        lineentry1.add(Entry(20f,2))
        lineentry1.add(Entry(70f,3))
        lineentry1.add(Entry(50f,4))



        val linedataset1 = LineDataSet(lineentry,"Second")
        linedataset1.color= resources.getColor(R.color.red)
       // data = LineData(xvalue1,linedataset1)

        data.addDataSet(linedataset1)


        val datacombine = CombinedData()
        datacombine.setData(data)
        //datacombine.setData(data1)

        combinechart.data = datacombine
        combinechart.setBackgroundColor(resources.getColor(R.color.white))
        combinechart.animateXY(3000,3000)

        val xval = combinechart.xAxis
        xval.position= XAxis.XAxisPosition.BOTTOM
        xval.setDrawGridLines(false)

    }




}
