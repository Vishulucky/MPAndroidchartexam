package com.example.barchartexample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.ScatterChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.XAxis.XAxisPosition
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.ScatterData
import com.github.mikephil.charting.data.ScatterDataSet
import com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
import kotlinx.android.synthetic.main.activity_scatter_chart.*


class ScatterChartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scatter_chart)

        scatterChartData()

    }

    fun scatterChartData()
    {

        val scatterentry= ArrayList<Entry>()

        scatterentry.add(Entry(20f,0))
        scatterentry.add(Entry(50f,1))
        scatterentry.add(Entry(70f,2))
        scatterentry.add(Entry(10f,3))
        scatterentry.add(Entry(30f,4))



        val scatterentry1= ArrayList<Entry>()

        scatterentry1.add(Entry(10f,0))
        scatterentry1.add(Entry(40f,1))
        scatterentry1.add(Entry(20f,2))
        scatterentry1.add(Entry(70f,3))
        scatterentry1.add(Entry(50f,4))




        val xval = ArrayList<String>()
        xval.add("11:00 am")
        xval.add("12:00 am")
        xval.add("3:00 pm")
        xval.add("6:00 pm")
        xval.add("8:00 pm")

        val scatterDataSet = ScatterDataSet(scatterentry, "first")
        scatterDataSet.color= resources.getColor(R.color.green)

        scatterDataSet.scatterShape= ScatterChart.ScatterShape.TRIANGLE


        val scatterDataSet1 = ScatterDataSet(scatterentry1, "second")

        scatterDataSet1.scatterShape= ScatterChart.ScatterShape.CIRCLE

        val scatterlistfinal = ArrayList<ScatterDataSet>()
        scatterlistfinal.add(scatterDataSet)
        scatterlistfinal.add(scatterDataSet1)

        val scatterData = ScatterData(xval, scatterlistfinal as List<IScatterDataSet>?)
        scatterchart.data =scatterData
        scatterchart.setBackgroundColor(resources.getColor(R.color.white))
        scatterchart.animateXY(3000,3000)


        val xaxis = scatterchart.xAxis
        xaxis.position= XAxisPosition.BOTTOM
        xaxis.setDrawGridLines(false)



    }





    
}
